SYNTAX 2026

Demo Oldskool computers 

"Nodetro"

Credits:
Code neffo / | the lostunderground |
GFX aZtOcKdOg / | the lostunderground |
Music hukka / | the lostunderground |

Platform: Amiga

Game demo out now!
https://tedzogh.itch.io/adventure-of-node


Creative Commons License:
Attribution-NonCommercial-NoDerivatives 4.0 International



| the lost underground |

wearetlu.net

 ._.    __  .__           ._. 
 | |  _/  |_|  |  __ __   | | 
 |_|  \   __\  | |  |  \  |_| 
 |-|   |  | |  |_|  |  /  |-| 
 | |   |__| |____/____/   | | 
 |_|                      |_| 